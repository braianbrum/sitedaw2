<?php 

include_once '../A/cabecalho.php';



include_once '../class/classUsuario.php';

$ObjUsuarios = new Usuario();

$ObjUsuarios->id_cliente=$_POST['id_cliente'];
$ObjUsuarios->sobrenome= $_POST['sobrenome'];
$ObjUsuarios->nome= $_POST['nome'];->email= $_POST['email'];
$ObjUsuarios->senha= $_POST['senha'];
$ObjUsuarios->telefone= $_POST['telefone'];
$ObjUsuarios->endereco= $_POST['endereco'];
$ObjUsuarios->cidade= $_POST['cidade'];
$ObjUsuarios->doc_identificacao= $_POST['doc_identificacao'];

$retorno = $ObjUsuarios->editarUsuario($ObjUsuarios);
if($retorno)

echo "EDITADO COM SUCESSO";

else 

echo "ERRO AO EDITAR";


include_once '../H/rodape.php';

?>