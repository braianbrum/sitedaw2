<!DOCTYPE HTML>
<!--
	Eleganta by TEMPLATED
    templated.co @templatedco
    Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>imagens</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="viewport" content="width=1040" />
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->

		<noscript>
			
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
		
		<link href="css/style.css" type="text/css" rel="stylesheet" />
		<link href="css/all.min.css" type="text/css" rel="stylesheet" />
		<link rel="stylesheet" type="text/css" href="vendor/owl.carousel.min.css"/>

	</head>
	<body  style="background-color:#d0d2e2;">
		<header id="cabecalho" style="background-color:black;">
		<nav id="cab">
				<img src="../hotel/H/hot.jpg" height="150px" width="600px"/>
		
		<a href="../Login/Login.php" style="color:yellow;float:right;text-decoration: none;font-family: Arial, Helvetica, sans-serif:25px;">LOGIN</a>
		
		</nav>
		<div id="menus" style="background-color:green;padding:3px;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;font-size: 25px;">
		<a href="../H/inicio.php" style="color:white;font:arial;text-decoration: none;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;">INICIO</a>
		<a href="../quarto/listarQuarto.php" style="color:white;font:arial;text-decoration:none;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;">QUARTOS</a>
		<a href="../hotel/imagens.html" style="color:white;font:arial;text-decoration:none;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;">IMAGENS</a>
		<a href="../H/contatos.php" style="color:white;font:arial;text-decoration: none;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;">CONTATOS</a>
		<a href="../clientes/addCliente.php" style="color:white;font:arial;text-decoration:none;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;">CADASTRE-SE</a>
		
		</div>
		
		
		</header>
		</nav>	
					<div>
						<div>
							<section>
								<header>
                                    <h2>FOTOS DO NOSSO HOTEL</h2>
                                    <br>
<!--style="background-color:skyblue; border-radius: 20px;" -->
									<section  id="slidess" style="background-color:rgb(196, 191, 191); border-radius:20px;">
											
											<div class="owl-carousel">
												<div class="item"><img src="../hotel/img/piscina.jpg"  height="300px" width="700px"><h2>Piscinas</h2>
													<h3>Piscina mas de 50 metros</h3></img></div>
												<div class="item"><img src="../hotel/img/quarto.jpg"  height="300px" width="700px"><h2>Quartos</h2>
													<h3>Quartos até 2 camas</h3></img></div>
												<div class="item"><img src="../hotel/img/salam.jpg"  height="300px" width="700px">  <h2>Sala de Massagem</h2>
													</img></div>
												<div class="item"><img src="../hotel/img/sauna.jpeg"  height="300px" width="700px"> <h2>Saunas</h2>
												</img></div>
												<div class="item"><img src="../hotel/img/banheiro.jpg"  height="300px" width="700px"><h2>Banheiros</h2>
													</img></div>
												<div class="item"><img src="../hotel/img/hotel.jpg"  height="300px" width="700px"> <h2>Imágem áerea<h3>HOTEL</h3></h2>
											</div>

									</section>



									
		<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
		<script type="text/javascript" src="vendor/owl.carousel.min.js"></script>
		 
		<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>-->
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
    
    	<script type="text/javascript" src="js/slider.js"></script>
									<section style="background-color:black;height:100px;">
									</br>
									<h5 style="color:white;font-family:'Times New Roman', Times, serif;text-align: center;">
													 IFSUL- curso Técnico em Informática para intrenet 2019 semestre 04
									</h5>
									
									
									
									 
									</section>
	</body>
</html>