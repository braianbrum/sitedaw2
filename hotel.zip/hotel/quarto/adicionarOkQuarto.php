<?php

include_once '../H/cabecalho.php';

//echo "<pre>";
//print_r($_POST);
include_once '../class/classQuarto.php';
$ObjQuartos = new Quarto();

$ObjQuartos->id_quarto=$_POST["id_quarto"];
$ObjQuartos->descricaoQuarto=$_POST["descricaoQuarto"];//erro
$ObjQuartos->preco=$_POST['preco'];

$retorno = $ObjQuartos->AddQuarto();
if($retorno){

    
    echo "quarto Adicionado com sucesso!!!";
}
    else 
    echo "ERRO ao cadastrar Quarto";
    
include_once '../H/rodape.php';
?>