<?php

include_once '../H/cabecalho.php';
include_once '../class/classQuarto.php';

$ObjQuartos = new Quarto();

$listarQuartos = $ObjQuartos->listarQuarto();


?>

<h1>QUARTOS </h1>
<br>
<table border='2';>
<thead>

<th>nro_porta</th>
<th>descricaoQuarto</th>
<th>preco</th>
</thead>
<tbody>

<?php


foreach($listarQuartos as $linha){

    echo "<tr>";
      echo "<td>".$linha->nro_porta."</td>";
    echo "<td>".$linha->descricaoQuarto;"</td>";
    echo "<td>".$linha->preco;"</td>";

  
    

    echo"<td><a href='addReservas.php?id=".$linha->nro_porta."'>RESERVAR</a></td>";
    //echo"<td><a href='editarQuarto.php?id=".$linha->nro_porta."'>Editar</a></td>";
   // echo"<td><a href='ExcluirQuarto.php?id=".$linha->nro_porta."'>Excluir</a></td>";
        echo "</tr>"; 
  


}




?>

</tbody>
</table>
<?php

include_once '../H/rodape.php';
?>