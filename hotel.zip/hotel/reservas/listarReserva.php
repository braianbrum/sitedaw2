<?php 
include_once '../H/cabecalho.php';
include_once '../class/classReservas.php';

$ObjReservas = new Reserva();

$listarReservas  = $ObjReservas->listarReserva();
?>


<h1>RESERVAS</h1>
<br>
<table border='5'>

<thead>
    <th>id_reservas</th>
    <th>clientes_id_cliente</th>
    <th>dataInicial</th>
    <th>dataFinal</th>
    <th>reservas_nro_quarto</th>
 
</thead>
<tbody>


<?php
foreach($listarReservas as $linha){
    echo "<tr>";
    echo "<td>".$linha->id_reservas."</td>";
    echo "<td>".$linha->clientes_id_cliente."</td>";
    echo "<td>".$linha->dataInicial."</td>";
    echo "<td>".$linha->dataFinal."</td>";
    echo "<td>".$linha->reservas_nro_quarto."</td>";


 
}

?>
</tbody>
</table>
<?php
include_once '../H/rodape.php';
?>