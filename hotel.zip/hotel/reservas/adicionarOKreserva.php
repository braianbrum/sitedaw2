<?php

include_once '../H/cabecalho.php';

//echo "<pre>";
//print_r($_POST);
include_once '../class/classReservas.php';


$ObjReservas = new Reserva();

$ObjReservas->id_reservas=$_POST['id_reservas'];
$ObjReservas->clientes_id_cliente= $_POST['clientes_id_cliente'];
$ObjReservas->dataInicial= $_POST['dataInicial'];
$ObjReservas->dataFinal= $_POST['dataFinal'];
$ObjReservas->reservas_nro_porta= $_POST['reservas_nro_porta'];



$retorno = $ObjReservas->editarCliente($ObjReservas);

if($retorno)

echo "RESERVA CADASTRADA COM SUCESSO!!!";

else
    echo "Erro ao fazer RESERVA";

    include_once '../H/rodape.php';

?>