<?php

class Reserva{

    private $id_reservas;
    private $clientes_id_cliente;
    private $dataInicial;
    private $dataFinal;
    private $quartos_nro_porta;




    private $connection;
    private $tabela;

    public function construct(){
        $this->connection = mysqli_connect("localhost", "root","", "hotel")
        or die("não rolou");

        $this->tabela="reservas";

    }

    public function destruct(){

        unset($this->connection);

    }

    public function __get($name){

        return $this->$name;
    }

    public function __set($name,$value){

        $this->$name=$value;
    }
public function AddReservas(){
    $this->connection=mysqli_connect("localhost", "root","", "hotel") or die("não rolou");
  
   
    $sql= "INSERT INTO reservas (dataInicial, dataFinal) values ('$this->dataInicial','$this->dataFinal')";



    $resultado = mysqli_query($this->connection, $sql);
    //var_dump($this->connection);
    return $resultado;
  

}
  
public function listarReservas(){
    $this->connection=mysqli_connect("localhost", "root","", "hotel") or die("não rolou");
  
   
     
    $sql=  "SELECT  * FROM reservas  INNER JOIN quartos ON reservas.id_reservas = clientes.clientes_id_cliente AND clientes.id_cliente;";
    $resultado= mysqli_query($this->connection,$sql);    
    echo $sql;
    
    $retorno = null;
    while($res= mysqli_fetch_assoc($resultado)){

       // var_dump($res);die;
        $ObjReservas= new Reserva();

        $ObjReservas->id_reservas=$res['reservas'];
        $ObjReservas->clientes_id_cliente=$res['clientes_id_cliente'];
        $ObjReservas->dataInicial=$res['dataInicial'];
        $ObjReservas->dataFinal=$res['dataFinal'];
        $ObjReservas->reservas_nro_quarto=$res['reservas_nro_quarto'];
        $retorno[]=$ObjReservas;
    }

    
         return  $retorno; 
    }





public function retornarUnicoReserva(){
    $this->connection=mysqli_connect("localhost", "root","", "hotel") or die("não rolou");
  
   

    $sql=" SELECT * FROM $this->tabela where dataInicial=$this->dataInicial";

    $resultado = mysqli_query($this->connection,$sql);
    $retorno = null;

    if($res = mysqli_fetch_assoc($resultado)){
        
$ObjReservas->clientes_id_cliente=$res['clientes_id_cliente'];
$ObjResevas->dataInicial=$res['dataInicial'];
$ObjResevas->dataFinal=$res['dataFinal'];
$ObjReservas->reservas_nro_quarto=$res['reservas_nro_quarto'];
       
$retorno = $ObjResevas;
    }
    return $retorno;
}


public function editarReserva($ObjReservas){
    $this->connection=mysqli_connect("localhost", "root","", "hotel") or die("não rolou");
    $sql = "UPDATE reservas SET id_reserva = '$this->id_reserva' WHERE id_reserva= '$this->id_reserva'";
    
  $resultado= mysqli_query($this->connection,$sql);

 //var_dump($resultado);
  return $resultado;
  
   }
public function excluirReserva(){
    $this->connection=mysqli_connect("localhost", "root","", "hotel") or die("não rolou");
  
   
    $sql=" DELETE * FROM reservas WHERE dataInicial'";
    $resultado= mysqli_query($this->connection,$sql);
    return $resultado;

}



public function insetrReserva(Reserva $reservas){
    $this->connection=mysqli_connect("localhost", "root","", "hotel") or die("não rolou");
  
   
    $connection;
        try{
            $connection= new PDO('mysql: host=127.0.0.1;dbname=hotel, root', ' ');


    $connection = beginTransaction();
    $sql = "INSERT reservas(clientes_id_cliente,dataInicial, dataFinal, reservas_nro_quarto) value(:clientes_id_cliente,:dataInicial,:dataFinal,:reservas_nro_quarto)";



    $prepareStament= $connection->prepare($sql);
    $prepareStament= bindValue(":clientes_id_cliente", $reservas->getclientes_id_cliente());
    $prepareStament= bindValue(":dataInicial", $reservas->getdataInicial());
    $prepareStament= bindValue(":dataFinal", $reservas->getdataFinal());
    $prepareStament= bindValue(":reservas_nro_quarto", $reservas->getreservas_nro_quarto());

   

    $prepareStament-> execute();
    $connection->commit();

    return "sucesso";

        }

        catch(PDOException $exc){
            if(isset($connection)&&($connection->inTransaction())){
                $connection->rollBack();
            }
            echo $exc-> getMessage();
            return "FALHA";
            }
        
        
        finally {
            if(isset($connection)){
            unset($connection);
            }
        }
    }



   
}
?>




