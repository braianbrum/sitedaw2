 
 <?php

include_once '../H/cabecalho.php';
include_once '../class/classPost.php';
$ObjPost= new Post();
$Post= $ObjPost->listarPost();
 

?>

 <section>
    <ul>

                            <?php 
                            
                            
                            foreach($Post as $item){
								?>
							
								<hr>
											
										
                                                    <?php echo $item->datadia ?>
                                                    <?php echo $item->hora ?>" 
                                                    <img src="../img/<?php echo $item->imagem; ?>" alt=""  height='130'/>
													<?php echo $item->texto ?>" 
														
											
										
									<div class="cbp-l-grid-projects-title"><?php 
									echo $item->text;
									?>
</hr>
								<?php
                                
							}
        
							 
?>
                            
                        </section>




<?php include_once '../H/rodape.php'; ?>