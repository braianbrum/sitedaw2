
<!DOCTYPE html>
<html>
<head>
<title>cabecalhoHotel</title>
</title>
<body  style="background-color:#d0d2e2;">
<header id="cabecalho" style="background-color:black">
<nav id="cab">
        <img src="../H/hot.jpg" height="150px" width="600px"/>

<a href="../Login/Login.php" style="color:yellow;float:right;text-decoration: none;font-family: Arial, Helvetica, sans-serif:25px;">LOGIN</a>

</nav>
<div id="menus" style="background-color:skyblue;padding:3px;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;font-size: 25px;">
<a href="../H/inicio.php" style="color:white;font:arial;text-decoration: none;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;">INICIO</a>
<a href="../quarto/listarQuarto.php" style="color:white;font:arial;text-decoration:none;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;">QUARTOS</a>
<a href="../imagens.php" style="color:white;font:arial;text-decoration:none;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;">IMAGENS</a>
    <a href="../H/contatos.php" style="color:white;font:arial;text-decoration:none;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;">CONTATOS</a>
<a href="../clientes/addCliente.php" style="color:white;font:arial;text-decoration:none;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;">CADASTRE-SE</a>

</div>


</header>
</nav>
</body>
</html>