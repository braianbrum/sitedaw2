<?php
include_once '../H/cabecalho.html';
?>

    <div id="contact" style="background-color:#f5f5f5;">
</br>
<h1 style="font-family: arial black;">CONTATOS</h1>
    <img src="../img/tel.png" height="50px" width="50px"/><h4 style="text-decoration:none;color:gray; font-family: arial black; font-size:20 px;">TELEFONE (+55)3242-5009</h4>
    <img src="../img/facebook.png" height="50px" width="50px"/><a href="https://www.facebook.com/" style="text-decoration:none;color:gray; font-family: arial black; font-size:20 px;">www.facebook.com/EstrelasDoCeu</a></br></br>
    <img src="../img/twitter.jpg" height="50px" width="50px"/><a href="https://twitter.com/" style="text-decoration:none;color:gray; font-family: arial black; font-size:20 px;">www.twitter.com/HotelEstrelasdoCeu</a></br></br>
    <img src="../img/whats.jpg" height="50px" width="50px"/> <h4 style="text-decoration:none;color:gray; font-family: arial black; font-size:20 px;"> (+55)98737-5609</h4></br></br>
    </form>
<section style="background-color:#f5f5f5;height:200px;">
</br>
<h5 style="color:white;font-family:'Times New Roman', Times, serif;">
               
</h5>


 
</section>

</div>



<?php
include_once '../H/rodape.html';
?>