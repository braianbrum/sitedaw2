$(document).ready(function(){


    $("h1").mouseover(function(){

        
        $("td").slideToggle("slow");
    });


    $(".cliente").mouseover(function(){

        
        $(".cliente").css("background-color","white");
        $(".1").css("color","black");
    });


    
    $(".usuario").mouseover(function(){

        
        $(".usuario").css("background-color","white");
        $(".2").css("color","black");
    });

    $(".post").mouseover(function(){

        
        $(".post").css("background-color","white");
        $(".3").css("color","black");
    });

    $(".quarto").mouseover(function(){

        
        $(".quarto").css("background-color","white");
        $(".4").css("color","black");
    });

    $(".reserva").mouseover(function(){

        
        $(".reserva").css("background-color","white");
        $(".5").css("color","black");
    });

    $(".login").mouseover(function(){

        
        $(".login").css("background-color","white");
        $(".6").css("color","black");
    });



});