-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 07-Dez-2019 às 15:58
-- Versão do servidor: 10.4.8-MariaDB
-- versão do PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `hotel`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `sobrenome` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `senha` varchar(45) DEFAULT NULL,
  `telefone` int(11) DEFAULT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  `doc_identificacao` varchar(45) DEFAULT NULL,
  `cidade` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nome`, `sobrenome`, `email`, `senha`, `telefone`, `endereco`, `doc_identificacao`, `cidade`) VALUES
(1, '', 'rodrigues alves', 'ana2019@gmail.com', 'ana1234F', 32425151, 'Andradas2001', '45821147', 'Santana do Livramanto'),
(5, 'Jose Alferdo', 'Gomes souza', 'JAlfredo1998@gmail.com', 'Fedinho99', 32420203, 'Almirante Barroso 568', '62525477', 'Santana do Livramanto'),
(6, 'RobertAAAAAAA', 'Vaz de Asis', 'RobertVaz77@hotmail.com', 'RobertV7701', 32445088, 'Andradas 2014', '91593574', 'Santana do Livramanto'),
(7, 'Samanta ', 'Almeida Prado', 'SamataAP@gmail.com', 'Samanta1994', 99654147, 'Sarandi 574', '43217534', 'Rivera'),
(18, 'Izabaela', 'Duarte', 'IzaDu2323@gmail.com', 'iza1234', 32425510, 'Rivadavia Correia 961', '62586514', 'Santana do Livramanto'),
(19, 'Izabaela', 'Duarte', 'IzaDu2323@gmail.com', 'iza1234', 32425510, 'Rivadavia Correia 961', '62586514', 'Santana do Livramanto'),
(20, 'Izabaela', 'Duarte', 'IzaDu2323@gmail.com', 'iza1234', 32425510, 'Rivadavia Correia 961', '62586514', 'Santana do Livramanto'),
(21, 'Ana Luiza', 'rodrigues alves', 'AnaLuiza23@gmail.com', 'anaLu2424', 32428565, 'Rivadavia Correia 97', '', ''),
(22, 'Ana Luiza', 'rodrigues alves', 'AnaLuiza23@gmail.com', '', 32428565, 'Rivadavia Correia 972', '4533369', 'Santana do Livramanto'),
(23, 'braian ', 'dos santos brum', 'anaPeres22@gmail.com', 'anaPeres2019', 110000000, 'aurelio carambula 461', '12589637', 'Rivera'),
(24, 'b', 'dos santos brum', 'anaPeres22@gmail.com', 'anaPeres2019', 110000000, 'aurelio carambula 461', '12589637', 'Rivera'),
(25, 'ssssssss', 'dsdf iweoieor', 'sddudu8ud@gmail.com', 'duwuuw77', 222222222, 'dswfjuf 65878', '14444444', 'Santana do Livramanto'),
(26, 'vvvvvvvv', 'cccccccccc', 'vaca2019@gmail.com', 'adcfff5e947da4569f2eabd4d775ad6c', 3548454, 'ghddhd 098', '544444447', 'rivera'),
(27, '', '', 'braiandossantos99@gmail.com', '23043e2bc6359d5d202d2de99b342b7f', 0, '', '', ''),
(28, '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', 0, '', '', ''),
(29, 'rergttt', 'rrrrr tttttt', 'b@gmail.com', '8393ea19abdcd8d5eac62afe8fd547af', 0, 'riyh   9999', '3233333', 'rivera');

-- --------------------------------------------------------

--
-- Estrutura da tabela `login`
--

CREATE TABLE `login` (
  `email` varchar(200) NOT NULL,
  `senha` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `post`
--

CREATE TABLE `post` (
  `id_post` int(11) NOT NULL,
  `datadia` date DEFAULT NULL,
  `hora` varchar(45) DEFAULT NULL,
  `imagem` varchar(100) DEFAULT NULL,
  `texto` varchar(800) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `post`
--

INSERT INTO `post` (`id_post`, `datadia`, `hora`, `imagem`, `texto`, `id_usuario`) VALUES
(111, '2019-12-11', '12:00', 'usuario.png', 'asdadasd', 2),
(112, '2019-12-19', '15:00', 'piscina.jpg', 'adadadasdasd', 1),
(113, '2019-12-19', '15:00', 'piscina.jpg', 'adadadasdasd', 1),
(114, '2019-12-19', '15:00', 'piscina.jpg', 'adadadasdasd', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `quartos`
--

CREATE TABLE `quartos` (
  `nro_porta` int(100) NOT NULL,
  `descricaoQuarto` varchar(100) DEFAULT NULL,
  `preco` decimal(20,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `quartos`
--

INSERT INTO `quartos` (`nro_porta`, `descricaoQuarto`, `preco`) VALUES
(1, '', '100'),
(2, '', '100'),
(3, '', '100'),
(4, '', '100'),
(5, '', '100'),
(6, '', '100'),
(7, '', '100');

-- --------------------------------------------------------

--
-- Estrutura da tabela `reservas`
--

CREATE TABLE `reservas` (
  `id_reservas` int(11) NOT NULL,
  `clientes_id_cliente` int(11) NOT NULL,
  `dataInicial` date DEFAULT NULL,
  `dataFinal` date DEFAULT NULL,
  `quartos_nro_porta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `sobrenome` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `senha` varchar(45) DEFAULT NULL,
  `telefone` int(11) DEFAULT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `doc_identificacao` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nome`, `sobrenome`, `email`, `senha`, `telefone`, `endereco`, `cidade`, `doc_identificacao`) VALUES
(1, 'joana silva', 'peres borges', 'anaPeres22@gmail.com', 'anaPeres2019', 32456974, 'conde de Porto alegre 848', 'Santana do Livramanto', '94561597'),
(2, 'braian ', 'brum', 'braiandossantos99@gmail.com', 'BB@2019', 0, '000000000', 'Rivera', '42583691'),
(3, 'maria ', 'do socorro', 'socorro@gmail.com', 'socorro2019', 32456212, 'tamandare 987', 'Santana do livramento', '62587894');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Índices para tabela `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id_post`);

--
-- Índices para tabela `quartos`
--
ALTER TABLE `quartos`
  ADD PRIMARY KEY (`nro_porta`);

--
-- Índices para tabela `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id_reservas`),
  ADD KEY `fk_reservas_clientes_idx` (`clientes_id_cliente`),
  ADD KEY `fk_reservas_quartos1_idx` (`quartos_nro_porta`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de tabela `post`
--
ALTER TABLE `post`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT de tabela `quartos`
--
ALTER TABLE `quartos`
  MODIFY `nro_porta` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id_reservas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `fk_reservas_clientes` FOREIGN KEY (`clientes_id_cliente`) REFERENCES `clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_reservas_quartos1` FOREIGN KEY (`quartos_nro_porta`) REFERENCES `quartos` (`nro_porta`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
